<template>
  <VmImageList
    :data="dataImageList"
    ref="child"
    @delete-ok="deletefn"
    @modify-ok="modifyfn"
    @reload="reloadfn"
    class="vm-margin"
  ></VmImageList>
</template>

<script>
import VmImageList from "@/components/vm-image-list";
// import moment from "moment";
export default {
  name: "ImageList",
  components: {
    VmImageList,
  },

  methods: {
    deletefn: function (data) {
      for (let i = 0; i < this.dataImageList.length; i++) {
        if (this.dataImageList[i].id === data.id) {
          this.$store.dispatch("deleteProjects", {
            id: data.id,
            wayOfOrder: this.$refs.child.wayOfOrder,
          });
          this.dataImageList.splice(i, 1);
        }
      }
    },
    modifyfn: function (data) {
      for (let i = 0; i < this.dataImageList.length; i++) {
        if (this.dataImageList[i].id === data.id) {
          let param = {
            id: data.id,
            title: data.title,
            desc: data.desc,
            img: data.img,
            wayOfOrder: this.$refs.child.wayOfOrder,
          };
          this.$store.dispatch("updateProjects", param);
        }
      }
    },
    reloadfn: function (data) {
      this.$store.dispatch("requestProjects", {
        wayOfOrder: data,
      });
      this.dataImageList = this.$store.state.dataImageList;
    },
  },
  data: function () {
    return {
      dataImageList: [],
    };
  },
  async mounted() {
    //初始化界面
    await this.$store.dispatch("requestProjects", {
      wayOfOrder: this.$refs.child.wayOfOrder,
    });
    this.dataImageList = this.$store.state.dataImageList;
  },
};
</script>
