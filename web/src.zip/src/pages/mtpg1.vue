<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    li {
        list-style: none;
    }
    .w {
        width: 1000px;
        margin:0 auto;
    }
    #main {
        position: relative;
        background-color: skyblue;
    }
    body {
        background: url('../assets/img/bg_footer.jpg') no-repeat center 0;
        background-attachment: fixed;
        background-position: bottom;
    }
    #project1 {
        position: absolute;
        top: 0;
        width: 100px;
        height: 40px;
        /* background-color: blue; */
    }
    #editpg {
        position: absolute;
        left: 100%;
        margin-left: -100px;
        width: 100px;
        height: 40px;
        /* background-color: chartreuse; */
    }
    #editpgb {
        width: 100px;
        height: 40px;
        border: none;
    }
    #savepgb {
        position: absolute;
        left: 100%;
        margin-left: -100px;
        width: 100px;
        height: 40px;
        border: none;
        display: none;
    }
    button:hover {
        cursor: pointer;
    }
    #boxpg {
        position: absolute;
        top: 60px;
        width: 100%;
        height: 100px;
        /* background-color: red; */
    }
    #pg {
        width: 100%;
        height: 60px;
        /* background-color: brown; */
        outline: none;
        border: none;
        font-size: 18px;
        resize: none;
    }
    #head2 {
        position: absolute;
        top: 170px;
        height: 40px;
        /* background-color: darkgreen; */
    }
    #page {
        float: left;
        width: 100px;
        height: 40px;
        /* background-color: darkmagenta; */
    }
    #addpg {
        float: right;
        width: 100px;
        height: 40px;
        /* background-color: deeppink; */
    }
    #addpgb {
        width: 100px;
        height: 40px;
        border: none;
    }
    #body {
        position: absolute;
        top: 210px;
        height: 100%;
        /* background-color: green; */
    }
    #body .pgtoc {
        float: left;
        margin: 10px;
        margin-top: 30px;
        width: 180px;
        height: 220px;
        background-color: red;
    }
    #body .pgch {
        width: 100%;
        height: 30px;
        background-color: wheat;
    }
    .pgtocbutton {
        float: right;
        background: rgba(0, 0, 0, 0.1);
        transition: background-color 0.5s,border-radius .5s;
        border: none;
        width: 30px;
        height: 30px;
    }
    .pgtocbutton:hover {
        background-color:rgba(0, 0, 0, 0.4);
        border-radius: 30px;
    }
    
    html,#body,#main {
        height: 100%;
    }
    .fontloca {
        line-height: 40px;
    }
    #pgtocmenu {
        position: absolute;
        top: 60px;
        left: 190px;
        background-color:blue;
        width: 70px;
        height: 100px;
    }
    #pgtocmenu ul li:nth-child(1) {
        border-bottom: 1px solid black;
    }
    #pgtocmenu ul li{
        height: 50px;
    }
    #pgbd {
        position: absolute;
        top:60px;
        left: 160px;
        width: 30px;
        height: 30px;
    }
    #pgbd:hover #pgtocmenu {
        display: block;
    }
    .bedit {
        float: right;
        
        background: rgba(0, 0, 0, 0.1);
        transition: background-color 0.5s;
        border: none;
        width: 70px;
        height: 50px;
        display: none;
    }
    .delect {
        float: right;
        margin-left: 70px;
        background: rgba(156, 149, 149, 0.1);
        transition: background-color 0.5s;
        border: none;
        width: 70px;
        height: 50px;
        display: none;
    }
    .bedit:hover {
        background-color: rgba(0, 0, 0, 0.4);
    }
    .delect:hover {
        background-color: rgba(0, 0, 0, 0.4);
    }
    #boxpghead {
        width: 100%;
        height: 40px;
        background-color: rgba(0, 0, 0, 0.1);
        display: none;
        
    }#boxpghead ul li {
        display: block;
        float: left;
        margin-left: 50px;
        line-height: 40px;
        height: 40px;
    }
    .pgtocbuttom {
        float: left;
    }
</style>
<template>
    <div id="main" class="w">
        <div id="head">
            <div id="project1" class="fontloca">
                <h3>项目</h3>
            </div>
            <div id="editpg"  class="fontloca">
                <button id="editpgb" class="pgtocbutton" @click="mouseenedit" ref="epgb">编辑</button>
                <button id="savepgb" class="pgtocbutton" @click="mouseensave" ref="spgb">保存</button>
            </div>
        </div>
        <div id="boxpg">
            <div id="boxpghead" ref="refboxpghead">
                <ul>
                    <li>H1</li>
                    <li>H2</li>
                    <li>H3</li>
                    <li>H4</li>
                    <li>H5</li>
                    <li>H6</li>
                    <li>H7</li>
                    <li>blockquote</li>
                    <li>ul</li>
                    <li>ol</li>
                    <li></li>
                </ul>
            </div>
            <textarea id="pg" value="" ref="textVal" name="textname" v-text="text">
                
            </textarea>
        </div> 
        <!-- <RichTextEditor></RichTextEditor> -->
        <div id="head2" class="w">
            <div id="page" class="fontloca">
                页面
            </div>
            <div id="addpg" class="fontloca">
                <button id="addpgb" class="pgtocbutton">新增页面</button>
            </div>
        </div>
        <div id="body" class="w">
            <div id="pgtoc1" class="pgtoc"><div class="pgch">页面1</div>
             <input type="button" id="button1" value="• • •" class="pgtocbutton" @click="test11" ref="refbutton1">
             <button ref="refbedit1" id="bedit1" class="bedit" @click="test12">编辑页面</button>
             <button ref="refdelect1" id="delect1" class="delect" @click="test13">删除页面</button>
             </div>
            <div id="pgtoc2" class="pgtoc"><div class="pgch">页面2</div>
             <input type="button" id="button2" value="• • •" class="pgtocbutton" @click="test21" ref="refbutton2">
             <button ref="refbedit2" id="bedit2" class="bedit" @click="test22">编辑页面</button>
             <button ref="refdelect2" id="delect2" class="delect" @click="test23">删除页面</button>
             </div>
            <div id="pgtoc3" class="pgtoc"><div class="pgch">页面3</div> 
             <input type="button" value="• • •" class="pgtocbutton" @click="test31" ref="refbutton3">
             <button ref="refbedit3" id="bedit3" class="bedit" @click="test32">编辑页面</button>
             <button ref="refdelect3" id="delect3" class="delect" @click="test33">删除页面</button>
             </div>
            <div id="pgtoc4" class="pgtoc"><div class="pgch">页面4</div>
             <input type="button" value="• • •" class="pgtocbutton" @click="test41" ref="refbutton4">
             <button ref="refbedit4" id="bedit4" class="bedit" @click="test42">编辑页面</button>
             <button ref="refdelect4" id="delect4" class="delect" @click="test43">删除页面</button>
             </div>
            <div id="pgtoc5" class="pgtoc"><div class="pgch">页面5</div>
             <input type="button" value="• • •" class="pgtocbutton" @click="test51" ref="refbutton5">
             <button ref="refbedit5" id="bedit5" class="bedit" @click="test52">编辑页面</button>
             <button ref="refdelect5" id="delect5" class="delect" @click="test53">删除页面</button>
             </div>
            <div id="pgtoc6" class="pgtoc"><div class="pgch">页面6</div>
             <input type="button" value="• • •" class="pgtocbutton" @click="test61" ref="refbutton6">
             <button ref="refbedit6" id="bedit6" class="bedit" @click="test62">编辑页面</button>
             <button ref="refdelect6" id="delect6" class="delect" @click="test63">删除页面</button>
             </div>
            <div id="pgtoc7" class="pgtoc"><div class="pgch">页面7</div>
             <input type="button" value="• • •" class="pgtocbutton" @click="test71" ref="refbutton7">
             <button ref="refbedit7" id="bedit7" class="bedit" @click="test72">编辑页面</button>
             <button ref="refdelect7" id="delect7" class="delect" @click="test73">删除页面</button>
             </div>
            <div id="pgtoc8" class="pgtoc"><div class="pgch">页面8</div> 
             <input type="button" value="• • •" class="pgtocbutton" @click="test81" ref="refbutton8">
             <button ref="refbedit8" id="bedit8" class="bedit" @click="test82">编辑页面</button>
             <button ref="refdelect8" id="delect8" class="delect" @click="test83">删除页面</button>
             </div>
            <div id="pgtoc9" class="pgtoc"><div class="pgch">页面9</div>
             <input type="button" value="• • •" class="pgtocbutton" @click="test91" ref="refbutton9">
             <button ref="refbedit9" id="bedit9" class="bedit" @click="test92">编辑页面</button>
             <button ref="refdelect9" id="delect9" class="delect" @click="test93">删除页面</button>
             </div>
            <div id="pgtoc10" class="pgtoc"><div class="pgch">页面10</div>
             <input type="button" value="• • •" class="pgtocbutton" @click="test101" ref="refbutton10">
             <button ref="refbedit10" id="bedit10" class="bedit" @click="test102">编辑页面</button>
             <button ref="refdelect10" id="delect10" class="delect" @click="test103">删除页面</button>
             </div>
            <div id="pgtoc11" class="pgtoc"><div class="pgch">页面11</div>
             <input type="button" value="• • •" class="pgtocbutton" @click="test111" ref="refbutton11">
             <button ref="refbedit11" id="bedit11" class="bedit" @click="test112">编辑页面</button>
             <button ref="refdelect11" id="delect11" class="delect" @click="test113">删除页面</button>
             </div>
            <div id="pgtoc12" class="pgtoc"><div class="pgch">页面12</div>
             <input type="button" value="• • •" class="pgtocbutton" @click="test121" ref="refbutton12">
             <button ref="refbedit12" id="bedit12" class="bedit" @click="test122">编辑页面</button> 
             <button ref="refdelect12" id="delect12" class="delect" @click="test123">删除页面</button>
             </div>
            <div id="pgtoc13" class="pgtoc"><div class="pgch">页面13</div>
             <input type="button" value="• • •" class="pgtocbutton" @click="test131" ref="refbutton13"> 
             <button ref="refbedit13" id="bedit13" class="bedit" @click="test132">编辑页面</button>
             <button ref="refdelect13" id="delect13" class="delect" @click="test133">删除页面</button>
             </div>
            <div id="pgtoc14" class="pgtoc"><div class="pgch">页面14</div>
             <input type="button" value="• • •" class="pgtocbutton" @click="test141" ref="refbutton14">
             <button ref="refbedit14" id="bedit14" class="bedit" @click="test142">编辑页面</button>
             <button ref="refdelect14" id="delect14" class="delect" @click="test143">删除页面</button>
             </div>
            <div id="pgtoc15" class="pgtoc"><div class="pgch">页面15</div>
             <input type="button" value="• • •" class="pgtocbutton" @click="test151" ref="refbutton15">
             <button ref="refbedit15" id="bedit15" class="bedit" @click="test152">编辑页面</button>
             <button ref="refdelect15" id="delect15" class="delect" @click="test153">删除页面</button>
             </div>
            <div id="pgtocb" class="pgtocbuttom">
                ©美团网团购meituan.com京ICP证070791号京ICP备10211739号-1

广播电视节目制作经营许可证（京）字第03889号

食品经营许可证互联网药品信息服务资格证 (京)-经营性-2017-0014

医疗器械网络交易服务第三方平台备案：（京）网械平台备字[2018]第00004号

平台EDI许可证

京公网安备 11000002002052号
北京三快科技有限公司备案信息12315消费争议
            </div>
            <div id="bgcbuttom" style="background:url('../assets/img/bg_footer.jpg')"></div>
            
        </div>
    </div>
</template>
<script src="../node_modules/vue/dist/vue.js"></script>
<script>

import RichTextEditor from  '@/components/RichTextEditor'
export default {
    components: {
      RichTextEditor
    },

    data(){
        return{
            text:'',
        }
        
    },
    methods:{
        test11(){
            this.$refs.refbutton1.style="display:none";
            this.$refs.refbedit1.style="display:block";
            this.$refs.refdelect1.style="display:block";
        },
        test12(){
            this.$refs.refbutton1.style="display:block";
            this.$refs.refbedit1.style="display:none";
            this.$refs.refdelect1.style="display:none";
        },
        test13(){
            this.$refs.refbutton1.style="display:block";
            this.$refs.refdelect1.style="display:none";
            this.$refs.refbedit1.style="display:none";
        },
        test21(){
            this.$refs.refbutton2.style="display:none";
            this.$refs.refbedit2.style="display:block";
            this.$refs.refdelect2.style="display:block";
        },
        test22(){
            this.$refs.refbutton2.style="display:block";
            this.$refs.refbedit2.style="display:none";
            this.$refs.refdelect2.style="display:none";
        },
        test23(){
            this.$refs.refbutton2.style="display:block";
            this.$refs.refdelect2.style="display:none";
            this.$refs.refbedit2.style="display:none";
        },
        test31(){
            this.$refs.refbutton3.style="display:none";
            this.$refs.refbedit3.style="display:block";
            this.$refs.refdelect3.style="display:block";
        },
        test32(){
            this.$refs.refbutton3.style="display:block";
            this.$refs.refbedit3.style="display:none";
            this.$refs.refdelect3.style="display:none";
        },
        test33(){
            this.$refs.refbutton3.style="display:block";
            this.$refs.refdelect3.style="display:none";
            this.$refs.refbedit3.style="display:none";
        },
        test41(){
            this.$refs.refbutton4.style="display:none";
            this.$refs.refbedit4.style="display:block";
            this.$refs.refdelect4.style="display:block";
        },
        test42(){
            this.$refs.refbutton4.style="display:block";
            this.$refs.refbedit4.style="display:none";
            this.$refs.refdelect4.style="display:none";
        },
        test43(){
            this.$refs.refbutton4.style="display:block";
            this.$refs.refdelect4.style="display:none";
            this.$refs.refbedit4.style="display:none";
        },
        test51(){
            this.$refs.refbutton5.style="display:none";
            this.$refs.refbedit5.style="display:block";
            this.$refs.refdelect5.style="display:block";
        },
        test52(){
            this.$refs.refbutton5.style="display:block";
            this.$refs.refbedit5.style="display:none";
            this.$refs.refdelect5.style="display:none";
        },
        test53(){
            this.$refs.refbutton5.style="display:block";
            this.$refs.refdelect5.style="display:none";
            this.$refs.refbedit5.style="display:none";
        },
        test61(){
            this.$refs.refbutton6.style="display:none";
            this.$refs.refbedit6.style="display:block";
            this.$refs.refdelect6.style="display:block";
        },
        test62(){
            this.$refs.refbutton6.style="display:block";
            this.$refs.refbedit6.style="display:none";
            this.$refs.refdelect6.style="display:none";
        },
        test63(){
            this.$refs.refbutton6.style="display:block";
            this.$refs.refdelect6.style="display:none";
            this.$refs.refbedit6.style="display:none";
        },
        test71(){
            this.$refs.refbutton7.style="display:none";
            this.$refs.refbedit7.style="display:block";
            this.$refs.refdelect7.style="display:block";
        },
        test72(){
            this.$refs.refbutton7.style="display:block";
            this.$refs.refbedit7.style="display:none";
            this.$refs.refdelect7.style="display:none";
        },
        test73(){
            this.$refs.refbutton7.style="display:block";
            this.$refs.refdelect7.style="display:none";
            this.$refs.refbedit7.style="display:none";
        },
        test81(){
            this.$refs.refbutton8.style="display:none";
            this.$refs.refbedit8.style="display:block";
            this.$refs.refdelect8.style="display:block";
        },
        test82(){
            this.$refs.refbutton8.style="display:block";
            this.$refs.refbedit8.style="display:none";
            this.$refs.refdelect8.style="display:none";
        },
        test83(){
            this.$refs.refbutton8.style="display:block";
            this.$refs.refdelect8.style="display:none";
            this.$refs.refbedit8.style="display:none";
        },
        test91(){
            this.$refs.refbutton9.style="display:none";
            this.$refs.refbedit9.style="display:block";
            this.$refs.refdelect9.style="display:block";
        },
        test92(){
            this.$refs.refbutton9.style="display:block";
            this.$refs.refbedit9.style="display:none";
            this.$refs.refdelect9.style="display:none";
        },
        test93(){
            this.$refs.refbutton9.style="display:block";
            this.$refs.refdelect9.style="display:none";
            this.$refs.refbedit9.style="display:none";
        },
        test101(){
            this.$refs.refbutton10.style="display:none";
            this.$refs.refbedit10.style="display:block";
            this.$refs.refdelect10.style="display:block";
        },
        test102(){
            this.$refs.refbutton10.style="display:block";
            this.$refs.refbedit10.style="display:none";
            this.$refs.refdelect10.style="display:none";
        },
        test103(){
            this.$refs.refbutton10.style="display:block";
            this.$refs.refdelect10.style="display:none";
            this.$refs.refbedit10.style="display:none";
        },
        test111(){
            this.$refs.refbutton11.style="display:none";
            this.$refs.refbedit11.style="display:block";
            this.$refs.refdelect11.style="display:block";
        },
        test112(){
            this.$refs.refbutton11.style="display:block";
            this.$refs.refbedit11.style="display:none";
            this.$refs.refdelect11.style="display:none";
        },
        test113(){
            this.$refs.refbutton11.style="display:block";
            this.$refs.refdelect11.style="display:none";
            this.$refs.refbedit11.style="display:none";
        },
        test121(){
            this.$refs.refbutton12.style="display:none";
            this.$refs.refbedit12.style="display:block";
            this.$refs.refdelect12.style="display:block";
        },
        test122(){
            this.$refs.refbutton12.style="display:block";
            this.$refs.refbedit12.style="display:none";
            this.$refs.refdelect12.style="display:none";
        },
        test123(){
            this.$refs.refbutton12.style="display:block";
            this.$refs.refdelect12.style="display:none";
            this.$refs.refbedit12.style="display:none";
        },
        test131(){
            this.$refs.refbutton13.style="display:none";
            this.$refs.refbedit13.style="display:block";
            this.$refs.refdelect13.style="display:block";
        },
        test132(){
            this.$refs.refbutton13.style="display:block";
            this.$refs.refbedit13.style="display:none";
            this.$refs.refdelect13.style="display:none";
        },
        test133(){
            this.$refs.refbutton13.style="display:block";
            this.$refs.refdelect13.style="display:none";
            this.$refs.refbedit13.style="display:none";
        },
        test141(){
            this.$refs.refbutton14.style="display:none";
            this.$refs.refbedit14.style="display:block";
            this.$refs.refdelect14.style="display:block";
        },
        test142(){
            this.$refs.refbutton14.style="display:block";
            this.$refs.refbedit14.style="display:none";
            this.$refs.refdelect14.style="display:none";
        },
        test143(){
            this.$refs.refbutton14.style="display:block";
            this.$refs.refdelect14.style="display:none";
            this.$refs.refbedit14.style="display:none";
        },
        test151(){
            this.$refs.refbutton15.style="display:none";
            this.$refs.refbedit15.style="display:block";
            this.$refs.refdelect15.style="display:block";
        },
        test152(){
            this.$refs.refbutton15.style="display:block";
            this.$refs.refbedit15.style="display:none";
            this.$refs.refdelect15.style="display:none";
        },
        test153(){
            this.$refs.refbutton15.style="display:block";
            this.$refs.refdelect15.style="display:none";
            this.$refs.refbedit15.style="display:none";
        },
        test1(){
            alert('ssssss');
        },
        test2(){

        },
        mouseenedit(){
            //让文本框获取焦点
            this.$nextTick(function () {
            this.$refs.textVal.focus()
            this.$refs.textVal.style="background: rgba(0, 0, 0, 0.1)";
            this.$refs.epgb.style="display:none";
            this.$refs.spgb.style="display:block";
            this.$refs.refboxpghead.style="display:block";
            this.$refs.refboxpghead.style.border="2px solid gray";
            this.isnreadonly();
            })
        },
        mouseensave(){
            this.$refs.epgb.style="display:block";
            this.$refs.spgb.style="display:none";
            this.$refs.refboxpghead.style="display:none";
            this.$refs.textVal.style="background:rgba(0, 0, 0, 0)";
            this.isreadonly();
        },
        textstyleborder(){
            
        },
        isreadonly(){
            var obj = document.getElementById("pg");
            obj.setAttribute("readonly",true);
        },
        isnreadonly(){
            var obj1 = document.getElementById("pg").readOnly=false;
        },


        init(){

        }


    },
    async mounted(){
        console.log(this.$route.query.projectId);
        await this.$store.dispatch("requestPages", {id:this.$route.query.projectId});
        console.log(this.$store.state.text)
        this.text = this.$store.state.text;
        
    }
}
</script>
