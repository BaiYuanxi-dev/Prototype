import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'base',
    component: () => import('../pages/ImageList')
  },
  {
    path: '/mtpg1',
    name: 'mtpg1',
    component: () => import('../pages/mtpg1')
  },
]

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes
})

export default router