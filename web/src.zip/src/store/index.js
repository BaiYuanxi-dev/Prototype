import Vue from 'vue';
import Vuex from 'vuex';
import {reqInstance} from '../request/config';
import moment from 'moment';

Vue.use(Vuex)

export default new Vuex.Store({
    state: {
        bases: [],
        projects:[],
        dataImageList:[],
        pagesList:[],
        text:'',
    },
    mutations: {
        setBases(state, bases) {
            state.bases = bases;
        },
        setProjects(state, dataImageList) {
            state.dataImageList = dataImageList;
            for(let i = 0; i < state.dataImageList.length; i ++){
                let str = state.dataImageList[i].img;
                state.dataImageList[i].img = require('@/assets/' + state.dataImageList[i].img);
                if(state.dataImageList[i].createdAt == null){
                    state.dataImageList[i].createdAt = "时间未记录"
                } else{
                    state.dataImageList[i].createdAt = moment(state.dataImageList[i].createdAt).format('YYYY-MM-DD HH:mm:ss') 
                }

                if(state.dataImageList[i].desc == ""){
                    state.dataImageList[i].desc = "简介"
                }
              }
        },
        addData(state, newData){
            // console.log(newData)
            newData.img = require('@/assets/' + newData.img);
            state.dataImageList.splice(0, 0, newData);
            // console.log(state.dataImageList);
        },
        changeData(state, changeData){
            changeData.img = require('@/assets/' + changeData.img);

            for(let i = 0; i < state.dataImageList.length; i ++){
                if(state.dataImageList[i].id == changeData.id){
                    state.dataImageList.splice(i, 1, changeData);
                }
            }
        },

        setPages(state, value){
            state.pagesList =  value.data;
            state.text = value.text[0].text;
            // console.log(this.text);
        }
    },
    actions: {
        async requestProjects(context, payload) {
            // const value = await reqInstance.get('/projects');
            /**
             * wayoforder：排序方式
             * return value: 服务器返回的值
             */
            let value = await reqInstance.post('/projects/try', {
                wayOfOrder:payload.wayOfOrder,
            });
            if(value.message == "ok"){
                context.commit('setProjects', value.data);//设置页面要显示的内容
            }
            
        },

        async addProjects(context, payload) {
            let addMsg = await reqInstance.post('/projects', {
                title: payload.title,
                desc: payload.desc
            });
            if(addMsg.message == "ok"){
                context.commit('addData', addMsg.data[0]);
            }
            
        },
        async deleteProjects(context, payload) {
            await reqInstance.delete(`/projects/${payload.id}`);
        },
        async updateProjects(context, payload) {
            const value = await reqInstance.post(`/projects/update`, {
                id:payload.id,
                title: payload.title,
                desc: payload.desc,
                img:payload.img,
            });
            if(value.message == "ok"){
                context.commit('changeData', value.data[0]);
            }
        },





        /**
         * 获得所有页面信息
         * @param {*} context 
         * @param {*} payload 
         */
        async requestPages(context, payload) {
            const value = await reqInstance.post('/pages', {id: payload.id});
            if(value.message == "ok"){
                context.commit('setPages', value);//设置页面要显示的内容
            }
            
        },

        async addPages(context, payload) {
            let addMsg = await reqInstance.post('/pages/add', {
                title: payload.title,
            });
            
        },
        async deletePages(context, payload) {
            await reqInstance.delete(`/pages/${payload.id}`);
        },
        async updatePages(context, payload) {
            const value = await reqInstance.post(`/pages/update`, {
                id:payload.id,
                title: payload.title,
                img:payload.img,
            });
        },

        async updateText(context, payload) {
            const value = await reqInstance.post(`/projects/updateText`, {
                id:payload.id,
                text: payload.text,
            });
        },
    }
})
